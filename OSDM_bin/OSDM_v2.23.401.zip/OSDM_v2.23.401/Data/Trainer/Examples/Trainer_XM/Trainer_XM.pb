;*********************************************
;* OSDM Trainer XM DLL v1.0 (easy test only) *
;* ----------------------------------------- *
;* Coded � 28-03-2010 by Peace^TST           *
;* ----------------------------------------- *
;* plays FastTracker2 (xm) by keys F1-F12    *
;*********************************************

#DLL  =  0  ;*** 1 = compile as dll / 0 = run as test

CompilerIf  #DLL

;Mainstructure
Structure   my_struct
   *Ptr     ;Address pointer of song
   Len.i    ;SizeOF(Song)
   Ret.l    ;Use LONG for PB3.94 compatibility
EndStructure   :  Global   MY.my_struct

Import   "Include\winmm.lib"  :  EndImport
Import   "Include\ufmod.lib"
   XMGetRowOrder()                        As "_uFMOD_GetRowOrder@0"
   XMGetStats()                           As "_uFMOD_GetStats@0"
   XMGetTime()                            As "_uFMOD_GetTime@0"
   XMGetTitle()                           As "_uFMOD_GetTitle@0"
   XMJump2Pattern(pat)                    As "_uFMOD_Jump2Pattern@4"
   XMPause()                              As "_uFMOD_Pause@0"
   XMPlaySong(*lpXM, param=0, fdwSong=0)  As "_uFMOD_PlaySong@12"
   XMResume()                             As "_uFMOD_Resume@0"
   XMSetVolume(vol)                       As "_uFMOD_SetVolume@4"
EndImport

#XM_RESOURCE         =  0
#XM_MEMORY           =  1
#XM_FILE             =  2
#XM_NOLOOP           =  8
#XM_SUSPENDED        =  16
#uFMOD_MIN_VOL       =  0
#uFMOD_MAX_VOL       =  25
#uFMOD_DEFAULT_VOL   =  #uFMOD_MAX_VOL

ProcedureDLL   F_Init()

   ;*** enter your initialsource here

   MessageRequester("Init", "Hello world :D", #MB_ICONINFORMATION)

EndProcedure
ProcedureDLL   F_Key(*Param)

   With  MY

      If \Ret  :  XMPlaySong(#NUL)  :  EndIf

      Select   PeekS(*Param)
      Case  "F1"  :  \Ptr  =  ?F1   :  \Len  =  ?F1_End  -  ?F1
      Case  "F2"  :  \Ptr  =  ?F2   :  \Len  =  ?F2_End  -  ?F2
      Case  "F3"  :  \Ptr  =  ?F3   :  \Len  =  ?F3_End  -  ?F3
      Case  "F4"  :  \Ptr  =  ?F4   :  \Len  =  ?F4_End  -  ?F4
      Case  "F5"  :  \Ptr  =  ?F5   :  \Len  =  ?F5_End  -  ?F5
      Case  "F6"  :  \Ptr  =  ?F6   :  \Len  =  ?F6_End  -  ?F6
      Case  "F7"  :  \Ptr  =  ?F7   :  \Len  =  ?F7_End  -  ?F7
      Case  "F8"  :  \Ptr  =  ?F8   :  \Len  =  ?F8_End  -  ?F8
      Case  "F9"  :  \Ptr  =  ?F9   :  \Len  =  ?F9_End  -  ?F9
      Case  "FA"  :  \Ptr  =  ?FA   :  \Len  =  ?FA_End  -  ?FA
      Case  "FB"  :  \Ptr  =  ?FB   :  \Len  =  ?FB_End  -  ?FB
      Case  "FC"  :  \Ptr  =  ?FC   :  \Len  =  ?FC_End  -  ?FC
      Default
         \Ptr  =  #NUL
         \Len  =  #NUL
         \Ret  =  #NUL
      EndSelect

      If \Ptr  And   \Len
         \Ret  =  XMPlaySong(\Ptr, \Len, #XM_MEMORY)
      EndIf

      ProcedureReturn   \Ret

   EndWith

   DataSection
      IncludePath    "Songs\"
      F1:   IncludeBinary  "F1_DeepInMySoul.xm"    :  F1_End:
      F2:   IncludeBinary  "F2_Wave.xm"            :  F2_End:
      F3:   IncludeBinary  "F3_LittleSad.xm"       :  F3_End:
      F4:   IncludeBinary  "F4_SearchBackups.xm"   :  F4_End:
      F5:   IncludeBinary  "F5_DammSugar.xm"       :  F5_End:
      F6:   IncludeBinary  "F6_Summer.xm"          :  F6_End:
      F7:   IncludeBinary  "F7_SilverTears.xm"     :  F7_End:
      F8:   IncludeBinary  "F8_Chipostalgica.xm"   :  F8_End:
      F9:   IncludeBinary  "F9_Selector.xm"        :  F9_End:
      FA:   IncludeBinary  "FA_HeartAche.xm"       :  FA_End:
      FB:   IncludeBinary  "FB_JumpAndRun.xm"      :  FB_End:
      FC:   IncludeBinary  "FC_Noizzz.xm"          :  FC_End:
   EndDataSection

EndProcedure
ProcedureDLL   F_End()

   ;*** enter your finish source here

   With  MY
      If \Ret  :  XMPlaySong(#NUL)  :  EndIf
      \Ret  =  #NUL
   EndWith

   MessageRequester("End", "That's all folks!", #MB_ICONINFORMATION)

EndProcedure

CompilerElse

If OpenLibrary(0, "Trainer_XM.dll")

   CallFunction(0, "F_Init")   ;*** s. ProcedureDLL F_Init()

   OpenWindow(0, 0, 0, 320, 80, "Trainer Test", #PB_Window_SystemMenu|#PB_Window_ScreenCentered)
   TextGadget(0, 0,30, 320, 16, "Press key [ F1 ] upto [ F12 ] to play songs or [ ESC ] to exit!", #PB_Text_Center)

   Repeat

      EventID  =  WaitWindowEvent()

      Select   EventwParam()
      Case     #VK_F1   :  f.s   =  "F1"
      Case     #VK_F2   :  f.s   =  "F2"
      Case     #VK_F3   :  f.s   =  "F3"
      Case     #VK_F4   :  f.s   =  "F4"
      Case     #VK_F5   :  f.s   =  "F5"
      Case     #VK_F6   :  f.s   =  "F6"
      Case     #VK_F7   :  f.s   =  "F7"
      Case     #VK_F8   :  f.s   =  "F8"
      Case     #VK_F9   :  f.s   =  "F9"
      Case     #VK_F10  :  f.s   =  "FA"
      Case     #VK_F11  :  f.s   =  "FB"
      Case     #VK_F12  :  f.s   =  "FC"
      Case     #VK_ESCAPE  :  EventID  =  #WM_CLOSE
      EndSelect

      If f.s   <> fn.s
         CallFunction(0, "F_Key", @f)   ;*** s. ProcedureDLL F_Key(*Param)
         SetGadgetText(0, "Playing song by key: " + f)
         fn =  f
      EndIf

   Until EventID  =  #WM_CLOSE

   CloseWindow(0)

   CallFunction(0, "F_End")   ;*** s. ProcedureDLL F_End()
   CloseLibrary(0)

EndIf

CompilerEndIf
